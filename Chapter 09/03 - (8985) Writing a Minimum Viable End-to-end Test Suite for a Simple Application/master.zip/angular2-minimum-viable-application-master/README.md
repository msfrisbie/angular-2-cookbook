# angular2-minimum-viable-application
