import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  template: '<h1>AppComponent template!</h1>'
})
export class AppComponent {}
